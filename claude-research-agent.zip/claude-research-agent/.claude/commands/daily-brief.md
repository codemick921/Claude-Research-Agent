---
description: Generate the morning brief from recent captures and research
allowed-tools: Read, Write, Glob
---

You are already inside the vault root; use relative paths and no shell commands.
Read everything in 00-INBOX/ from the last 24 hours (including any research-run reports)
and everything in 01-CAPTURES/ and 05-RESEARCH/ from the last 7 days. Then do three things:

CONNECTIONS — the 3 most interesting links between recent items and older notes I have
probably not noticed. Be specific and name the files/sources.
PATTERN — one pattern across everything this week. What is my attention clearly on?
QUESTION — one question worth sitting with today, based on that pattern. Not a task.

Save the result to 00-INBOX/brief-<YYYY-MM-DD>.md. Do this in a single pass — do not spawn
subagents (this command is designed to run unattended).
