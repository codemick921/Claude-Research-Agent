---
description: Interrogate everything in the vault about a topic
argument-hint: [topic]
allowed-tools: Read, Glob, Grep
---

You are already inside the vault root; use relative paths and no shell commands.
Topic: $ARGUMENTS

Read everything in the vault related to this topic, then tell me four things:
1. What I already believe, based on my actual notes — not generically.
2. What I have saved that contradicts that belief — both sides, from my notes.
3. What perspective is clearly missing, based on what I am and am not reading.
4. The single most important question I have not asked yet.
Be direct. Challenge me. Do not summarise what I already know.
