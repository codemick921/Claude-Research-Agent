---
description: Monthly synthesis of how my thinking is evolving
allowed-tools: Read, Glob, Grep
---

You are already inside the vault root; use relative paths and no shell commands.
Read everything added to the vault in the last 30 days. Tell me: what beliefs am I forming
that I have not stated yet; what pattern keeps recurring across domains; the single
highest-leverage thing I could focus on now; and what the gaps in my notes suggest I am
not reading but should be. Only insights specific to my actual notes. No generic advice.
