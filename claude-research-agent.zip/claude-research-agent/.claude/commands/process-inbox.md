---
description: Process and file everything in 00-INBOX from the last 24 hours
allowed-tools: Read, Write, Edit, Glob
---

You are already inside the vault root; use relative paths and no shell commands.
Read every note in 00-INBOX/ from the last 24 hours. For each note:
1. Decide which 01-CAPTURES/ subfolder it belongs in (articles / ideas / patterns /
   questions / numbers).
2. Sharpen the raw capture into one specific, punchy sentence.
3. Move it to the correct subfolder.

A sharpened note should be specific enough that a stranger understands exactly what was
observed without extra context. After processing, tell me: total notes processed and
where each went, any patterns across today's captures, and one connection worth exploring.
