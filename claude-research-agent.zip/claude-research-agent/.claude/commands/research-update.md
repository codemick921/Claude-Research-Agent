---
description: Run one research pass on tracked topics and update their dossiers
argument-hint: [optional single topic slug]
allowed-tools: WebSearch, WebFetch, Read, Write, Edit, Glob
---

You are already running inside the vault's root folder. Use Read, Write, Edit and Glob
with paths relative to here (e.g. 05-RESEARCH/<slug>.md and 00-INBOX/...). Never prefix
paths with the vault's folder name. Never use cd, mkdir, or any shell command — the
05-RESEARCH/ and 00-INBOX/ folders already exist; just write into them.

Read RESEARCH.md for the global rules, output format, and topic list. If a topic slug was
passed as an argument ($ARGUMENTS), process only that topic; otherwise process every
active topic.

For each topic:
1. Open 05-RESEARCH/<slug>.md. If missing, create it using the structure below. Read its
   "Sources already covered" list — this is your dedup ledger.
2. Use WebSearch for the topic's angles, biased to the latest info. WebSearch is primary.
   You may try WebFetch for detail, but if a fetch fails, use the search summary and keep
   going — never let one failed fetch stop the run.
3. Keep only findings that are new (URL not in the ledger) and relevant per "watch for".
4. Update the dossier without deleting anything: prepend new findings to "## Changelog",
   add their URLs to "## Sources already covered", revise "## Current state" only if
   something material changed, note contradictions under "## Contradictions & shifts".

When all topics are done, write a short report to 00-INBOX/research-run-<date-time>.md:
topics run, new findings per topic, the single most important update, and any errors.

Structure for a new dossier file:

# Research Dossier: <topic>

## Current state
<one-paragraph living summary>

## Changelog
- [YYYY-MM-DD] finding — source URL

## Contradictions & shifts

## Sources already covered
- <url>
