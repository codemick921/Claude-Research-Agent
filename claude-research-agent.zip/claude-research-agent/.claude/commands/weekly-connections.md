---
description: Find this week's strongest cross-domain connections
allowed-tools: Read, Write, Glob
---

You are already inside the vault root; use relative paths and no shell commands.
Read all notes added to 01-CAPTURES/ and 05-RESEARCH/ in the last 7 days. Find strong
connections of four types: A) same principle in two different domains; B) a contradiction
that creates tension; C) a pattern across three+ notes; D) a question one note answers in
another. For each: name the type, write a one-sentence bridge, and create a note in
02-CONNECTIONS/ linking the sources with [[wikilinks]]. Min 3, max 5. Only genuine surprises.
